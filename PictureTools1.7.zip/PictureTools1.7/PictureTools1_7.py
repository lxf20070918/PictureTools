

'''
                                          P i c t u r e T o o l s  -  1 . 7
'''


'''
导入模块
'''

# 我使用的gui库是基本easygui
import easygui as g
# 这是很重要的一个库，比如导入插件的时候会用
import sys
# 这个库也很牛X，可以实现多线程
import threading as th
# random模块是取随机数的
import random as r
# datetime用于判断时间
import datetime as d
# os可以处理文件
import os
# requests和json用于爬虫
import requests
import json
# socket可以判断是否联网
import socket
# win32clipboard可以编辑剪切板
import win32clipboard as w
# 这两个用于下载最新版本
import urllib.request as u
import re
import zipfile as z
import webbrowser as web

'''
导入插件
'''
# 这里添加的path是为了在导入工具插件时导入其他文件夹下的东东

# 账号信息文件夹路径
sys.path.append("AccountInformation/")
# 工具文件夹路径
sys.path.append("ToolsOfficialEdition/")
sys.path.append("ToolsHistorical/")


# 必要插件
import Remove

# 正式版本
import PictureZoom1_1 as pz1_1
import CharacterRecognition1_0 as cr1_0
import PictureSearch1_0 as ps1_0
import PictureRecognition1_0 as pr1_0

#beta版本

#历史版本
import PictureZoom1_0Historical as pzh
import FontPicture1_0Historical as fph

'''
初始化（init）
'''

# 变量

# 获取账号信息需要有缓存
cache = ""
firstEventCache = ""

# 当前图片工具版本
PictureToolsEdition = "1.7"

# 活动1开始、结束时间
firstEventTime = ("2020-10-01", "2020-10-08")

startTimeCache = firstEventTime[0].split("-")
startTime = startTimeCache[0] + "年" + startTimeCache[1] + "月" + startTimeCache[2] + "日"

endTimeCache = firstEventTime[1].split("-")
endTime = endTimeCache[0] + "年" + endTimeCache[1] + "月" + endTimeCache[2] + "日"

# 初始化变量（储存账号信息的变量）

#变量注释：
#1.LV为lastVersion的缩写，指最新版本

accountNums = []
passwords = []
integral = []
freeDrawTimes = []
signInInfor = []
VIP = []
buyVipCard = []
email = []
firstEventMsg = []
city = []

# 读取账号信息
f = open("AccountInformation/AccountInformation.txt", "r", encoding="utf-8")
accounttxt = f.read()
f.close()

f = open("AccountInformation/FirstEvent.txt", "r")
firstEventtxt = f.read()
f.close()

# 账号信息还是比较好保存的
# 只要按照格式就可以方便下次读取
# 每次变量i为账户信息中的项，并接下来判断

for i in accounttxt:

    # i为xxx的情况，即xxx缓存完毕，把xxx添加到账号信息

    # ——#前面是账号
    if i == "#":
        accountNums.append(cache)
        cache = ""

    # ——*前面是密码
    elif i == "*":
        passwords.append(cache)
        cache = ""

    # ——$前面是积分
    elif i == "$":
        integral.append(int(cache))
        cache = ""

    # ——`前面是免费抽奖次数
    elif i == "`":
        freeDrawTimes.append(int(cache))
        cache = ""

    # ——&前面是最近一次签到时间
    elif i == "&":
        signInInfor.append(cache)
        cache = ""

    # ——^前面是会员到期时间，如果不是会员，那么前面是“ptyh”
    elif i == "^":
        VIP.append(cache)
        cache = ""

    # ——%前面是否购买过VIP体验卡
    elif i == "%":
        buyVipCard.append(cache)
        cache = ""

    # ——!前面是绑定的邮箱
    elif i == "!":
        email.append(cache)
        cache = ""
    # ——\n(换行)前面是所在城市
    elif i == "\n":
        city.append(cache)
        cache = ""

    # 如果一个账号的一个信息还没添加完，继续添加到缓存
    else:
        cache += i

for i in firstEventtxt:
    # ——\n前面是账号
    if i == "\n":
        firstEventMsg.append(firstEventCache)
        firstEventCache = ""

    else:
        firstEventCache += i

'''
定义函数
'''

# 定义函数的好处是可以让程序的逻辑部分突出
# 这样在编写程序时就不那么容易受到实现功能部分的代码的干扰
# 且定义后可以多次调用
# 账号的信息经常会变动（如积分增减等），所以需要更新（保存）


# 打印账号信息
# print(accountNums,passwords,integral,freeDrawTimes,signInInfor,VIP,buyVipCard,email,firstEventMsg,city)


# 排除中文
def excludingChinese(str):
    for i in str:
        if "\u4e00" <= i <= "\u9fff":
            return False
    return True

# 写入剪切板
def writeClipboard(str):
    w.OpenClipboard()
    w.EmptyClipboard()
    w.SetClipboardText(str)
    w.CloseClipboard()

# 获取星期几
def getWeekDay(date):
  weekDayDict = {0 : '星期一', 1 : '星期二', 2 : '星期三', 3 : '星期四', 4 : '星期五', 5 : '星期六', 6 : '星期天'}
  day = date.weekday()
  return weekDayDict[day]

# 更新账号信息
def updateAccount():
    f = open("AccountInformation/AccountInformation.txt", "w")
    f.write("")
    f.close()
    for i in range(len(accountNums)):
        f = open("AccountInformation/AccountInformation.txt", "a", encoding="utf-8")
        f.write(accountNums[i] + "#" + passwords[i] + "*" + str(integral[i]) + "$"+ str(freeDrawTimes[i]) + "`"+
                signInInfor[i] + "&"+ VIP[i] + "^" + buyVipCard[i] + "%" + email[i] + "!" + city[i] + "\n")
        f.close()

    if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
        f = open("AccountInformation/FirstEvent.txt", "w")
        f.write("")
        f.close()
        for i in range(len(accountNums)):
            f = open("AccountInformation/FirstEvent.txt", "a")
            f.write(firstEventMsg[i] + "\n")
            f.close()

# 发送邮件（smtp服务器，发送者，授权码，接收者，邮件标题，邮件正文）
def sendEmail(smtpServer, sender, password, recipient, emailTitle, emailText):
    # 首先导入email模块构造邮件
    from email.mime.text import MIMEText
    import smtplib

    # 构造邮件内容
    msg = MIMEText(emailText)
    # 设置邮件主题
    msg["Subject"] = emailTitle
    # 寄件者
    msg["From"] = sender
    # 收件者
    msg["To"] = recipient

    # smtp服务器
    smtpServer = smtpServer
    # 发件人邮箱、授权码
    fromAddr = sender
    password = password
    # 收件人邮箱
    toAddr = recipient
    try:
        # smtp协议的默认端口是25，QQ邮箱smtp服务器端口是465,第一个参数是smtp服务器地址，第二个参数是端口，第三个参数是超时设置,这里必须使用ssl证书，要不链接不上服务器
        server = smtplib.SMTP_SSL(smtpServer, 465, timeout = 2)
        # 登录邮箱
        server.login(fromAddr, password)
        #发送邮件，第一个参数是发送方地址，第二个参数是接收方列表，列表中可以有多个接收方地址，表示发送给多个邮箱，msg.as_string()将MIMEText对象转化成文本
        server.sendmail(fromAddr, [toAddr], msg.as_string())
        server.quit()
        return True
    except Exception:
        return False

# 更新日志
def updateLog():
    logList = os.listdir("UpdateLog")
    logNum = len(logList)
    def switchLog(logNum):
        f = open(r"UpdateLog\UpdateLog"+str(logNum) + ".txt","r",encoding="utf-8")
        logMsg = f.read()
        f.close()
        if logNum == len(logList):
            button = ["下一页", "返回"]
        elif logNum == 1:
            button = ["上一页", "返回"]
        else:
            button = ["上一页", "下一页", "返回"]
        switchLogOperation = g.buttonbox(msg=logMsg, title="图片工具" + PictureToolsEdition + "版本——更新日志", choices=button)
        if switchLogOperation == "上一页":
            logNum += 1
            switchLog(logNum)
        elif switchLogOperation == "下一页":
            logNum -= 1
            switchLog(logNum)
    switchLog(logNum)

# 获取今天天气
def getTodayWeather(city):
    try:
        f = requests.get("http://wthrcdn.etouch.cn/weather_mini?city=" + city)
        data = json.loads(f.text)
        todayWeather = data['data']['forecast'][0]
        todayWeather.pop("date")
        fengLiCache = list(todayWeather["fengli"])
        del fengLiCache[0:9]
        del fengLiCache[-3:]
        fengLiCache2 = ""
        for i in fengLiCache:
            fengLiCache2 += i
        fengLiCache = fengLiCache2
        todayWeather["fengli"] = fengLiCache

        todayWeather["high"] = todayWeather["high"].split(" ")[1]
        todayWeather["low"] = todayWeather["low"].split(" ")[1]

        todayWeather = city + " " + todayWeather["type"] + " " + todayWeather["high"] + "-" + \
                       todayWeather["low"] + " " + todayWeather["fengxiang"] + " " + todayWeather["fengli"]
        return todayWeather
    except Exception:
        return "无法连接网络"

# 这个可以获取当前最新版本、下载链接和提取码等信息
def getLastVersion():
    url = "https://shimo.im/docs/xQ8CkCYKK3G83Ydj"
    ifmt = u.urlopen(url).read().decode()
    area = "——  (.*?)  ——"
    latestVersion = re.findall(area, ifmt)[0]
    area = "~~  (.*?)  ~~"
    downloadWay = re.findall(area, ifmt)[0]
    area = "URL—(.*?)—URL"
    GitHubUrl = re.findall(area, ifmt)[0]
    area = "=== (.*?) ==="
    BaiDuUrl = re.findall(area, ifmt)[0]
    area = "----- (.*?) -----"
    BaiDuPassword = re.findall(area, ifmt)[0]
    # print(latestVersion, downloadWay, GitHubUrl, BaiDuUrl, BaiDuPassword)
    return latestVersion, downloadWay, GitHubUrl, BaiDuUrl, BaiDuPassword

# 判断是否可以连接此网络
def internetAccess():
    def isNetOK(testserver):
        s = socket.socket()
        s.settimeout(3)
        try:
            status = s.connect_ex(testserver)
            if status == 0:
                s.close()
                return True
            else:
                return False
        except Exception:
            return False

    def isNetChainOK(testserver=("www.baidu.com", 443)):
        isOK = isNetOK(testserver)
        return isOK

    chinanet = isNetChainOK()
    return chinanet

def downloadLastVersion(downloadUrl):
    path = os.getcwd()
    beforePath = path
    path = path.split("\\")
    path.pop(len(path) - 1)
    pathCache = ""
    for i in path:
        pathCache += i + "\\"
    path = pathCache

    fileName = "PictureToolsLastVersionZip"

    f = u.urlopen(downloadUrl)
    data = f.read()
    with open(path + fileName, "wb") as code:
        code.write(data)

    os.chdir(path)
    decompress = z.ZipFile(fileName)
    decompress.extractall(path)
    decompress.close()
    os.chdir(beforePath)
    os.remove(path + fileName)


# 真正的东西如下

'''
登录
'''
def signIn(error,tips):

    # global关键字可以将你自定义的函数里创建的局部变量变为全局变量（这样在其他自定义函数里面也可以使用了）

    global inputAccount
    global accountSubscript
    global signInError
    global signInTips

    # 获取用户输入的账号和密码
    signInInput = g.multpasswordbox(msg="请登录（如果你绑定了邮箱，可以输入邮箱来登录；"
                "如果你忘记了密码请回到“开始”界面，选择忘记密码）" + error,
                title="图片工具" + PictureToolsEdition + "版本——登录", fields=("账号或邮箱","密码"),values=tips)

    # 这个判断你可能觉得很奇怪，其实也是有原因的：
    # 登录输入只有在用户按下“取消”的时候值才为 None ，如何用户什么都没输入，值应该是 "" 。
    # 忘记说了，按下“取消”是=时，返回值是None，那么这个登录输入也是一个数据
    # 这里只用一个 登录输入 来接收返回值也是因为如果你按下“取消”的返回值是一个数据
    # 如果直接用两个变量接受一个数据，显然是不行的，会报错

    if signInInput != None:
        # 由于之前获取输入返回值是一个列表，列表的0项是账号，1项是密码，所以要赋值两个变量
        inputAccount, inputPassword = signInInput[0], signInInput[1]
        # 先判断输入账号与输入密码是否在获取的账号信息内
        if inputAccount in accountNums or inputAccount in email and inputAccount != "wbd":
            if inputPassword in passwords:
                # 再获取账号的下标看看输入的密码与对应的正确密码是否一致
                if inputAccount in accountNums:
                    accountSubscript = accountNums.index(inputAccount)
                else:
                    accountSubscript = email.index(inputAccount)
                    inputAccount = accountNums[accountSubscript]
                if inputPassword == passwords[accountSubscript]:
                    # 如果一致，那么进入首页
                    global latestVersion, LVDownloadWay, LVGitHubUrl, LVBaiDuUrl, LVBaiDuPassword
                    if internetAccess():
                        # 获取最新版本、最新版本下载链接和最新版本提取码
                        latestVersion, LVDownloadWay, LVGitHubUrl, LVBaiDuUrl, LVBaiDuPassword = getLastVersion()
                    else:
                        latestVersion = "未连接网络"

                    if PictureToolsEdition != latestVersion and latestVersion != "未连接网络":
                        if g.ccbox(msg="当前最新版本为" + latestVersion + "版本，建议你安装最新版本的图片工具。",
                                   title="图片工具" + PictureToolsEdition + "——检查更新", choices=("下载最新版本", "暂不下载")):
                            if LVDownloadWay == "GitHub下载":
                                try:
                                    isDownload = True
                                    downloadLastVersion(LVGitHubUrl)
                                except Exception:
                                    isDownload = False
                                    g.msgbox(msg="无法连接网络，" + latestVersion + "版本下载失败，请确认联网或稍后再试。",
                                             title="图片工具" + PictureToolsEdition + "——检查更新", ok_button="确定")
                                    homePage()
                                if isDownload == True:
                                    g.msgbox(msg="图片工具" + latestVersion + "版本安装成功，即将卸载此版本图片工具，请在卸载后打开最新版本的图片工具。",
                                             title="图片工具" + PictureToolsEdition + "——检查更新", ok_button="卸载")
                                    Remove.remove(PictureToolsEdition)
                            else:
                                writeClipboard(LVBaiDuPassword)
                                if g.msgbox(msg="由于无法直接连接下载，将为你打开百度网盘下载网页自行下载，提取码：" + LVBaiDuPassword + "。点击“确定”打开。",
                                            title="图片工具" + PictureToolsEdition + "——检查更新", ok_button="确定") == "确定":
                                    web.open_new(LVBaiDuUrl)
                                    homePage()
                        else:
                            homePage()
                    else:
                        homePage()
                else:
                    # 如果错误，那么再来一次
                    signInError = "\n\n错误：密码输入错误！"
                    signInTips = [inputAccount, accountSubscript]
                    signIn(signInError,signInTips)
            else:
                # 如果错误，那么再来一次
                signInError = "\n\n错误：密码输入错误！"
                signInTips = [inputAccount, inputPassword]
                signIn(signInError,signInTips)
        else:
            # 如果错误，那么再来一次
            signInError = "\n\n错误：不存在此账号或邮箱！"
            signInTips = [inputAccount, inputPassword]
            signIn(signInError,signInTips)
    else:
        # 如果用户登录时点击“取消”，那么返回开始界面
        start()

'''
注册
'''
def register(tips):
    # 具体错误也是要转为全局变量的
    # 因为注册的原理是先基本的注册并获取用户输入
    # 但是如果输入错误怎么办呢
    # 所以这时就会设定一个具体错误的变量
    # 先赋一个值然后调用注册函数
    # 这时就会提示一个错误
    # 还有就是因为第一次获取注册输入时没有错误
    # 把""赋值于具体错误就可以了
    global registerError
    global registerAccount
    registerInput = g.multenterbox(msg="请注册" + registerError, title="图片工具" + PictureToolsEdition + "版本——注册",fields=("账号", "密码", "确认密码"),values=tips)
    # 与登录函数里的相同，就不多说了
    if registerInput != None:
        # 这个函数是根据所有汉字都...的原理做出的一个判断字符串是否不含中文的函数，后面判断要用到
        # 如果不含中文返回True,如果含有中文则返回False

        registerAccount, registerPassword, registerConfirmationPassword = registerInput[0], registerInput[1], registerInput[2]
        # 账号长度最大为20位
        if len(registerAccount) <= 20:
            # 账号只能由数字和字母组成
            # isalnum函数可以判断字符串是否只由数字和字母组成
            # 如果只由它们组成，那么返回True，相反返回False
            # 但是经过我的测试发现，这个函数无法判断中文
            # 也就是实际效果是数字、字母、汉字都可以
            # 所以才需要再次判断是否不含中文
            if registerAccount.isalnum() and excludingChinese(registerAccount):
                # 判断是否有小伙伴注册了同一个账号
                if not registerAccount in accountNums:
                    # 为了安全，密码长度必须大于6
                    if len(registerPassword) >= 6:
                        # 同账号判断
                        if registerPassword.isalnum() and excludingChinese(registerPassword):
                            # 判断确认密码是否和密码相同
                            if registerConfirmationPassword == registerPassword:
                                # 既然有了新账户，账号信息就也要增加
                                accountNums.append(registerAccount)
                                passwords.append(registerPassword)
                                # 初始积分当然是0的啦
                                integral.append(0)
                                # 免费抽奖次数也是0
                                freeDrawTimes.append(0)
                                # 签到就随便弄个以前的时间吧
                                signInInfor.append("1949-10-01")
                                # 新账号，肯定是普通用户嘛
                                VIP.append("ptyh")
                                # 新账号，没有购买体验卡
                                buyVipCard.append("wgm")
                                # 这个时候还没绑定邮箱
                                email.append("wbd")
                                # 未设置城市
                                city.append("wsz")
                                # 活动一
                                if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
                                    firstEventMsg.append("wlq")
                                updateAccount()
                                wantToSetUpCity = g.buttonbox(msg="注册成功，建议你设置所在城市，以便在首页显示时间与天气，是否设置？",
                                                     title="图片工具" + PictureToolsEdition + "版本——注册", choices=("立即设置", "暂不设置"))
                                if wantToSetUpCity == "立即设置":
                                    setUpCity(accountNums.index(registerAccount))
                                elif wantToSetUpCity == "暂不设置":
                                    g.msgbox(msg="不选择你所在的城市将无法在首页看到你所在位置的天气信息，建议你设置所在城市，如果你想设置所在城市，"
                                                 "可以到设置——通用设置中寻找。", title="图片工具" + PictureToolsEdition + "版本——注册",
                                             ok_button="我知道了")
                                updateAccount()
                                wantToBindEmail = g.buttonbox(msg="建议尽快绑定你的邮箱，以便密码修改，是否绑定邮箱？",
                                                     title="图片工具" + PictureToolsEdition + "版本——注册", choices=("立即绑定", "暂不绑定"))
                                if wantToBindEmail == "立即绑定":
                                    bindEmail(accountNums.index(registerAccount), "注册")
                                elif wantToBindEmail == "暂不绑定":
                                    g.msgbox(msg="如果你想绑定邮箱，请到设置——绑定邮箱，如果没有绑定邮箱，忘记密码时将无法修改密码。",
                                             title="图片工具" + PictureToolsEdition + "版本——注册",ok_button="我知道了，立即登录")
                                    signInError = ""
                                    registerTips = ["", ""]
                                    signIn(signInError,registerTips)
                            else:
                                registerError = "\n\n错误：确认密码必须和密码相同！"
                                registerTips = [registerAccount, registerPassword, registerConfirmationPassword]
                                register(registerTips)
                        else:
                            registerError = "\n\n错误：密码只能由数字和字母组成！"
                            registerTips = [registerAccount, registerPassword, registerConfirmationPassword]
                            register(registerTips)
                    else:
                        registerError = "\n\n错误：密码长度至少为6！"
                        registerTips = [registerAccount, registerPassword, registerConfirmationPassword]
                        register(registerTips)
                else:
                    registerError = "\n\n错误：已经有用户创建了此账号！"
                    registerTips = [registerAccount, registerPassword, registerConfirmationPassword]
                    register(registerTips)
            else:
                registerError = "\n\n错误：账号只能由数字和字母组成！"
                registerTips = [registerAccount, registerPassword, registerConfirmationPassword]
                register(registerTips)
        else:
            registerError = "\n\n错误：账号长度不得超过20！"
            registerTips = [registerAccount, registerPassword, registerConfirmationPassword]
            register(registerTips)
    else:
        start()

'''
忘记密码
'''
def forgetPassword(error):
    yourAccount = g.enterbox(msg="请输入你的账号："+error, title="图片工具" + PictureToolsEdition + "版本——忘记密码")
    if yourAccount != None:
        if yourAccount in accountNums:
            if email[accountNums.index(yourAccount)] != "wbd":
                def sendVerificationCode(error):
                    def inputNewPassword(error, tips):
                        newPasswordInput = g.multenterbox(msg="请输入你的账号" + yourAccount + "的新密码：" + error,
                                            title="图片工具" + PictureToolsEdition + "版本——忘记密码", fields=("密码", "确认密码"), values=tips)
                        if newPasswordInput != None:
                            newPassword = newPasswordInput[0]
                            newConfirmationPassword = newPasswordInput[1]
                            if len(newPassword) >= 6:
                                if newPassword.isalnum() and excludingChinese(newPassword):
                                    if newPassword == newConfirmationPassword:
                                        passwords[accountNums.index(yourAccount)] = newPassword
                                        updateAccount()
                                        g.msgbox(msg="你的账号" + yourAccount + "密码成功修改为" + newPassword,
                                                 title="图片工具" + PictureToolsEdition + "版本——忘记密码", ok_button="立即登录")
                                        signInError = ""
                                        signInTips = [newPassword, newConfirmationPassword]
                                        signIn(signInError, signInTips)
                                    else:
                                        newPasswordError = "\n\n错误：确认密码必须和密码相同！"
                                        newPasswordTips = [newPassword, newConfirmationPassword]
                                        inputNewPassword(newPasswordError, newPasswordTips)
                                else:
                                    newPasswordError = "\n\n错误：密码只能由数字和字母组成！"
                                    newPasswordTips = [newPassword, newConfirmationPassword]
                                    inputNewPassword(newPasswordError, newPasswordTips)
                            else:
                                newPasswordError = "\n\n错误：密码长度至少为6！"
                                newPasswordTips = [newPasswordError, newConfirmationPassword]
                                inputNewPassword(newPasswordError, newPasswordTips)
                        else:
                            start()
                    verificationCodeInput = g.enterbox(msg="已向你绑定的邮箱" + email[accountNums.index(yourAccount)] + "发送了验证码，请查收邮件并输入你收到的验证码：" + error,
                                        title="图片工具" + PictureToolsEdition + "版本——忘记密码")
                    if verificationCodeInput == str(verificationCode):
                        newPasswordError = ""
                        newPasswordTips = ["", ""]
                        inputNewPassword(newPasswordError,newPasswordTips)
                    else:
                        verificationCodeError = "\n\n验证码输入错误，请再次输入！"
                        sendVerificationCode(verificationCodeError)

                verificationCode = ""
                for i in range(3):
                    verificationCode += str(r.randint(10, 99))
                emailMsg = "你正在图片工具修改密码，验证码为：" + verificationCode + "，若非你本人操作，请忽略此消息。"
                if sendEmail("smtp.126.com", "lxf20070918@126.com", "NHKNCIKBQOLHQNKD", email[accountNums.index(forgetPassword)], "图片工具修改密码验证码", emailMsg):
                    verificationCodeError = ""
                    sendVerificationCode(verificationCodeError)
                else:
                    g.msgbox(msg="发送邮件错误，可能是......错误，你可以联系作者进行修复。",
                             title="图片工具" + PictureToolsEdition + "版本——忘记密码", ok_button="再次尝试")
                    forgetPasswordError = ""
                    forgetPassword(forgetPasswordError)
            else:
                g.msgbox(msg="你的账号并没有绑定邮箱，无法通过邮箱修改密码。", title="图片工具" + PictureToolsEdition + "版本——忘记密码",ok_button="确定")
                start()
        else:
            forgetPasswordError = "\n\n不存在此账号！"
            forgetPassword(forgetPasswordError)
    else:
        start()

'''
首页
'''
def homePage():
    if d.datetime.now().strftime("%Y-%m-%d") >= VIP[accountSubscript]:
        VIP[accountSubscript] = "ptyh"
        updateAccount()

    homePageMsg = d.datetime.now().strftime("%Y年%m月%d日 ") + getWeekDay(d.datetime.now()) + "                    "
    if city[accountSubscript] != "wsz":
        homePageMsg += getTodayWeather(city[accountSubscript])
    else:
        homePageMsg += "未设置城市"

    # 功能有：使用工具、签到、抽奖、积分商城
    if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
        homePageImg = "Image\\Img1.png"
        homePageOperation = g.buttonbox(msg=homePageMsg, image=(homePageImg, "Image\\Img3.png"), title="图片工具" + PictureToolsEdition + "版本——首页", choices=("工具", "我的", "设置"))
    else:
        homePageOperation = g.buttonbox(msg=homePageMsg, image="Image\\Img3.png", title="图片工具" + PictureToolsEdition + "版本——首页",
                                        choices=("工具", "我的", "设置"))
        # 各种操作
    if homePageOperation == "工具":
        tools()
    elif homePageOperation == "我的":
        my()
    elif homePageOperation == "设置":
        settings()
    elif homePageOperation == "Image\\Img1.png":
        firstEvent()
    elif homePageOperation == "Image\\Img3.png":
        updateLog()
        homePage()

# 活动1
def firstEvent():
    # if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
    f = open("EventDetails.txt", "r", encoding="utf-8")
    eventMsg = f.read()
    f.close()
    if firstEventMsg[accountSubscript] == "wlq":
        firstEventButton = "领取礼物"
    else:
        firstEventButton = "你已领取过礼物"
    g.msgbox(msg=eventMsg, title="图片工具" + PictureToolsEdition + "版本——活动", ok_button=firstEventButton)
    if firstEventMsg[accountSubscript] == "wlq":
        integral[accountSubscript] += 88
        freeDrawTimes[accountSubscript] += 10
        if VIP[accountSubscript] == "ptyh":
            VIP[accountSubscript] = (d.datetime.now() + d.timedelta(days=15)).strftime("%Y-%m-%d")
        # 如果本来就是VIP那么就要先使用datetime函数根据str时间生成一个datetime的特定数据类型的时间
        else:
            expirationDate = VIP[accountSubscript].split("-")
            for i in range(len(expirationDate)):
                expirationDate[i] = int(expirationDate[i])
            VIP[accountSubscript] = (d.datetime(expirationDate[0], expirationDate[1],
                expirationDate[2]) + d.timedelta(days=15)).strftime("%Y-%m-%d")
        firstEventMsg[accountSubscript] = "ylq"
        updateAccount()
        g.msgbox(msg="你成功领取了礼物：88积分+10次免费抽奖次数+VIP15天卡，快去查收吧！",
                 title="图片工具" + PictureToolsEdition + "版本——活动", ok_button="确定")
        homePage()
    else:
        homePage()
    # else:
        # g.msgbox(msg="活动已结束，活动时间为" + startTime + "至" + endTime +
        # "，等待下一次福利吧！", title = "图片工具" + PictureToolsEdition + "版本——活动", ok_button = "确定")
        # homePage()

'''
工具
'''
def tools():
    def betaTools():
        g.msgbox(msg="暂时没有beta版本，过过再来看看吧。", title="图片工具" + PictureToolsEdition + "版本——beta版本", ok_button="确定")
        tools()

        # 暂时木有beta版本的工具
        '''
        betaToolsOperation = g.buttonbox(msg="请选择你想要使用的beta版本", title="图片工具" 
        + PictureToolsEdition + "——beta版本", choices=("图片工具beta版本", "返回"))
        if betaToolsOperation == "图片工具beta版本":
            # 图片工具beta版
            try:
                pass
            except Exception as a:
                g.msgbox(msg="你在使用 图片缩放工具beta版本 时程序发生了错误，已强制结束程序。\n"
                             "错误类型：" + str(type(a)), title="图片工具" + PictureToolsEdition +
                              "——beta版本错误", ok_button="确定")
            if "PictureZoomCache.png" in os.listdir():
                os.remove("PictureZoomCache.png")
            tools()
        elif betaToolsOperation == "返回":
            tools()
        '''

    def historicalTools():
        betaToolsOperation = g.buttonbox(msg="请选择你想要使用的历史版本", title="图片工具" + PictureToolsEdition + "版本——历史版本", choices=("图片缩放1.0版本", "字体图片1.0版本", "返回"))
        if betaToolsOperation == "图片缩放1.0版本":
            try:
                pzh.PictureZoom1_0Historical()
            except Exception as a:
                g.msgbox(msg="你在使用 图片缩放1.0版本 时程序发生了错误，已强制结束程序。\n"
                             "错误类型：" + str(type(a)), title="图片工具" + PictureToolsEdition +
                                        "版本——历史版本错误", ok_button="确定")
            tools()

        elif betaToolsOperation == "字体图片1.0版本":
            try:
                fph.FontPicture1_0Historical()
            except Exception as a:
                g.msgbox(msg="你在使用 字体图片1.0版本 时程序发生了错误，已强制结束程序。\n"
                             "错误类型：" + str(type(a)), title="图片工具" + PictureToolsEdition
                                            + "版本——历史版本错误", ok_button="确定")
            tools()

        elif betaToolsOperation == "返回":
            tools()

    # 选择工具
    f = open("ToolsMsg.txt", "r", encoding="utf-8")
    toolsMsg = f.read()
    f.close()

    toolsOperation = g.buttonbox(msg=toolsMsg, title="图片工具" + PictureToolsEdition + "版本——工具",
    image=("Image\\PictureZoomImg.png", "Image\\CharacterRecognitionImg.png", "Image\\PictureSearchImg.png", "Image\\PictureRecognitionImg.png"),
    choices=("☜首页", "beta版本", "历史版本", "我的☞"))

    if toolsOperation == "☜首页":
        homePage()
    elif toolsOperation == "Image\\PictureZoomImg.png":
        integral[accountSubscript] += pz1_1.PictureZoom1_1()
        updateAccount()
        tools()

    elif toolsOperation == "Image\\CharacterRecognitionImg.png":
        if internetAccess():
            characterRecognitionReturn = cr1_0.CharacterRecognition1_0()
            if characterRecognitionReturn != "网络错误":
                integral[accountSubscript] += characterRecognitionReturn
                updateAccount()
            else:
                g.msgbox(msg="无法连接互联网，请检查你的网络是否正常。", title="图片工具" + PictureToolsEdition + "版本——beta版本",
                         ok_button="返回")
            tools()
        else:
            g.msgbox(msg="无法连接互联网，请检查你的网络是否正常。", title="图片工具" + PictureToolsEdition + "版本——beta版本",
                     ok_button="返回")
            tools()

    elif toolsOperation == "Image\\PictureSearchImg.png":
        if g.msgbox(msg="很抱歉，由于bug问题，图片搜索工具无法使用，作者将努力修复，你可以体验其他工具。",
                 title="图片工具" + PictureToolsEdition + "版本——beta版本", ok_button="好的") == "好的":
            tools()

    elif toolsOperation == "Image\\PictureRecognitionImg.png":
        if g.msgbox(msg="很抱歉，由于bug问题，图片识别工具无法使用，作者将努力修复，你可以体验其他工具。",
                 title="图片工具" + PictureToolsEdition + "版本——beta版本", ok_button="好的") == "好的":
            tools()
        #pr1_0.PictureRecognition1_0()
        #tools()

        '''
        if internetAccess():
            pictureSearchReturn = ps1_0.PictureSearch1_0()
            if pictureSearchReturn != "网络错误":
                integral[accountSubscript] += pictureSearchReturn
                updateAccount()
            else:
                g.msgbox(msg="无法连接互联网，请检查你的网络是否正常。", title="图片工具" + PictureToolsEdition + "版本——beta版本",
                         ok_button="返回")
            tools()
        else:
            g.msgbox(msg="无法连接互联网，请检查你的网络是否正常。", title="图片工具" + PictureToolsEdition + "版本——beta版本",
                     ok_button="返回")
            tools()
        '''

    elif toolsOperation == "beta版本":
        if VIP[accountSubscript] != "ptyh":
            betaTools()
        else:
            g.msgbox(msg="VIP用户才可体验beta版本，你还不是VIP用户哦。", title="图片工具" +
            PictureToolsEdition + "版本——beta版本", ok_button="返回")
            tools()

    elif toolsOperation == "历史版本":
        if VIP[accountSubscript] != "ptyh":
            historicalTools()
        else:
            g.msgbox(msg="VIP用户才可体验历史版本，你还不是VIP用户哦。", title="图片工具" +
            PictureToolsEdition + "版本——历史版本", ok_button="返回")
            tools()

    elif toolsOperation == "我的☞":
        my()

'''
我的
'''
def my():
    # 判断用户是不是普通会员，VIP会员的欢迎信息不一样
    if VIP[accountSubscript] == "ptyh":
        myMsg = "欢迎，" + inputAccount + "！"
    else:
        expirationDateCache = VIP[accountSubscript].split("-")
        expirationDate = expirationDateCache[0] + "年" + expirationDateCache[1] + "月" + expirationDateCache[2] + "日"
        myMsg = "欢迎VIP用户，" + inputAccount + "！"

        myMsg += "          " + expirationDate + "到期"

    if city[accountSubscript] != "wsz":
        myMsg += "\n\n城市：" + city[accountSubscript]
    else:
        myMsg += "\n\n城市：未设置"

    if email[accountSubscript] != "wbd":
        myMsg += "          邮箱：" + email[accountSubscript]
    else:
        myMsg += "          邮箱：未绑定"

    myMsg += "          积分："+str(integral[accountSubscript])

    # 功能有：使用工具、签到、抽奖、积分商城
    myOperation = g.buttonbox(msg=myMsg,
    title="图片工具" + PictureToolsEdition + "版本——我的",choices=("☜工具","每日\n签到", "幸运\n抽奖", "积分\n商城", "设置☞"))

    # 各种操作
    if myOperation == "☜工具":
        tools()
    elif myOperation == "每日\n签到":
        signInEveryDay()
    elif myOperation == "幸运\n抽奖":
        luckyDraw()
    elif myOperation == "积分\n商城":
        integralShop()
    elif myOperation == "设置☞":
        settings()

# 每日签到

def signInEveryDay():
    def signInReward(integralReward, freeDrawTimesReward, VipReward):
        global signInMsg

        signInIntegralNum = r.randint(1, 14)

        if 1 <= signInIntegralNum <= 3:
            signInInIntegral = integralReward[0]
        elif 4 <= signInIntegralNum <= 8:
            signInInIntegral = integralReward[1]
        elif 9 <= signInIntegralNum <= 11:
            signInInIntegral = integralReward[2]
        elif 12 <= signInIntegralNum <= 13:
            signInInIntegral = integralReward[3]
        else:
            signInInIntegral = integralReward[4]

        integral[accountSubscript] += signInInIntegral

        signInfreeDrawTimesNum = r.randint(1, 10)

        if signInfreeDrawTimesNum == 1:
            signInfreeDrawTimes = freeDrawTimesReward[0]
            freeDrawTimes[accountSubscript] += freeDrawTimesReward[0]
        elif 2 <= signInfreeDrawTimesNum <= 4:
            signInfreeDrawTimes = freeDrawTimesReward[1]
            freeDrawTimes[accountSubscript] += freeDrawTimesReward[1]
        else:
            signInfreeDrawTimes = freeDrawTimesReward[2]
            freeDrawTimes[accountSubscript] += freeDrawTimesReward[2]

        signInVipNum = r.randint(1, 30)

        if signInVipNum == 1:
            signInVip = VipReward[0]
        elif 2 <= signInVipNum <= 3:
            signInVip = VipReward[1]
        else:
            signInVip = 0

        if signInVip > 0:
            if VIP[accountSubscript] == "ptyh":
                VIP[accountSubscript] = (d.datetime.now() + d.timedelta(days=signInVip)).strftime("%Y-%m-%d")
            # 如果本来就是VIP那么就要先使用datetime函数根据str时间生成一个datetime的特定数据类型的时间
            else:
                expirationDate = VIP[accountSubscript].split("-")
                for i in range(len(expirationDate)):
                    expirationDate[i] = int(expirationDate[i])
                VIP[accountSubscript] = (d.datetime(expirationDate[0], expirationDate[1],
                expirationDate[2]) + d.timedelta(days=signInVip)).strftime("%Y-%m-%d")

        signInMsg = "签到成功，你获得了：" + str(signInInIntegral) + "个积分"

        if signInfreeDrawTimes > 0:
            signInMsg += "、" + str(signInfreeDrawTimes) + "次免费抽奖次数"

        if signInVip > 0:
            signInMsg += "、VIP" + str(signInVip) + "天卡"

        signInMsg += "。"

        signInInfor[accountSubscript] = d.datetime.now().strftime("%Y-%m-%d")
    # 判断今天是否签过到
    if signInInfor[accountSubscript] != d.datetime.now().strftime("%Y-%m-%d"):
        if VIP[accountSubscript] == "ptyh":
            if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
                signInReward([3, 4, 5, 6, 7], [3, 2, 1], [7, 3])
            else:
                signInReward([1, 2, 3, 4, 5], [2, 1, 0], [0, 0])
        else:
            if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
                signInReward([5, 6, 7, 8, 9], [5, 3, 2], [15, 7])
            else:
                signInReward([3, 4 , 5, 6, 7],[3, 2, 1], [7, 3])
        updateAccount()
        g.msgbox(msg=signInMsg, title="图片工具" + PictureToolsEdition + "版本——每日签到", ok_button="确定")
        my()
    else:
        g.msgbox(msg="你今天已经签过到了，明天再来吧！", title="图片工具" +
            PictureToolsEdition + "版本——每日签到", ok_button="确定")
        my()

# 抽奖功能

def luckyDraw():

    # 先定义一下抽奖1次，这样抽奖10次就没问题了
    def drawOnce():
        # 我的抽奖是很牛的，我先来介绍一下
        # 由于各个奖的中奖几率不一样，所以我需要用random模块里的randint函数随机取一个数1-10000
        # 然后根据这个数字，判断中啥奖，就是中奖几率大的范围越大，中它的几率也就越大，相反你想想也就知道了

        drawNum = r.randint(1, 10000)

        # 由于中了不同的奖，msg和ok_button也是不一样的，所以我干脆直接做一个函数，你应该能看懂
        def winningInformation(sizeOfAward, winningChance, nameOfAward):
            if sizeOfAward == "特等奖":
                msg = "瓦特？！瓦特？！！瓦特？！！！简直令人难以置信，你居然中了中奖几率只有" + \
                     winningChance + "的特等奖：" + nameOfAward + "！"
                button = "我肯定在做梦！"
                grandPrizeList.append(nameOfAward)
                return msg, button
            elif sizeOfAward == "一等奖":
                msg = "你是欧皇吧，居然中了中奖几率仅为" + winningChance + "的一等奖：" + nameOfAward + "！"
                button = "我是在做梦吗？"
                firstPrizeList.append(nameOfAward)
                return msg, button
            elif sizeOfAward == "二等奖":
                msg = "我的天，你居然中了中奖几率为" + winningChance + "的二等奖：" + nameOfAward + "！"
                button = "欣喜若狂地收下"
                secondPrizeList.append(nameOfAward)
                return msg, button
            elif sizeOfAward == "三等奖":
                msg = "运气真好，你中了中奖几率为" + winningChance + "的三等奖：" + nameOfAward + "！"
                button = "开心地收下"
                thirdPrizeList.append(nameOfAward)
                return msg, button
            elif sizeOfAward == "安慰奖":
                msg = "运气一般般哦，你只中中奖几率为" + winningChance + "的安慰奖：" + nameOfAward + "。"
                button = "收下安慰"
                consolationPrizeList.append(nameOfAward)
                return msg, button
            elif sizeOfAward == "谢谢参与":
                msg = "谢谢参与，不是每次都能中奖，也许着下一个就是大奖！"
                button = "我不气馁"
                thankYou.append(nameOfAward)
                return msg, button

        # 奖项里有VIP，所以抽到VIP增加VIP时间也要做成函数，参数就一个VIP的时间
        def getVip(time):
            if VIP[accountSubscript] == "ptyh":
                VIP[accountSubscript] = (d.datetime.now() + d.timedelta(days=time)).strftime("%Y-%m-%d")
            else:
                expirationDate = VIP[accountSubscript].split("-")
                for i in range(len(expirationDate)):
                    expirationDate[i] = int(expirationDate[i])
                VIP[accountSubscript] = (d.datetime(expirationDate[0], expirationDate[1],
                    expirationDate[2]) +d.timedelta(days=time)).strftime("%Y-%m-%d")

        # 以下就是我辛辛苦苦算了好多遍的概率中奖代码了

        # 特等奖
        if 1 <= drawNum <= 8:  # 518积分
            winningMsg, winningButton = winningInformation("特等奖", "0.24%", "518积分")
            integral[accountSubscript] += 518
        elif 9 <= drawNum <= 16:  # VIP季卡
            winningMsg, winningButton = winningInformation("特等奖", "0.24%", "VIP季卡")
            getVip(92)
        elif 17 <= drawNum <= 24:  # 50次抽奖
            winningMsg, winningButton = winningInformation("特等奖", "0.24%", "50次抽奖")
            freeDrawTimes[accountSubscript] += 50

        # 一等奖
        elif 25 <= drawNum <= 52:  # 208积分
            winningMsg, winningButton = winningInformation("一等奖", "0.84%", "208积分")
            integral[accountSubscript] += 208
        elif 53 <= drawNum <= 80:  # VIP月卡
            winningMsg, winningButton = winningInformation("一等奖", "0.84%", "VIP月卡")
            getVip(31)
        elif 81 <= drawNum <= 108:  # 30次抽奖
            winningMsg, winningButton = winningInformation("一等奖", "0.84%", "30次抽奖")
            freeDrawTimes[accountSubscript] += 30

        # 二等奖
        elif 109 <= drawNum <= 196:  # 98积分
            winningMsg, winningButton = winningInformation("二等奖", "2.64%", "98积分")
            integral[accountSubscript] += 98
        elif 197 <= drawNum <= 284:  # VIP15天卡
            winningMsg, winningButton = winningInformation("二等奖", "2.64%", "VIP15天卡")
            getVip(15)
        elif 285 <= drawNum <= 372:  # 20次抽奖
            winningMsg, winningButton = winningInformation("二等奖", "2.64%", "20次抽奖")
            freeDrawTimes[accountSubscript] += 20

        # 三等奖
        elif 373 <= drawNum <= 570:  # 38积分
            winningMsg, winningButton = winningInformation("三等奖", "7.92%", "38积分")
            integral[accountSubscript] += 38
        elif 571 <= drawNum <= 768:  # 18积分
            winningMsg, winningButton = winningInformation("三等奖", "7.92%", "18积分")
            integral[accountSubscript] += 18
        elif drawNum >= 769 and drawNum <= 966:  # VIP7天卡
            winningMsg, winningButton = winningInformation("三等奖", "7.92%", "VIP7天卡")
            getVip(7)
        elif 967 <= drawNum <= 1164:  # 10次抽奖
            winningMsg, winningButton = winningInformation("三等奖", "7.92%", "10次抽奖")
            freeDrawTimes[accountSubscript] += 10

        # 安慰奖
        elif 1165 <= drawNum <= 2452:  # 8积分
            winningMsg, winningButton = winningInformation("安慰奖", "51.52%", "8积分")
            integral[accountSubscript] += 8
        elif 2453 <= drawNum <= 3740:  # 5积分
            winningMsg, winningButton = winningInformation("安慰奖", "51.52%", "5积分")
            integral[accountSubscript] += 5
        elif 3741 <= drawNum <= 5028:  # 2积分
            winningMsg, winningButton = winningInformation("安慰奖", "51.52%", "2积分")
            integral[accountSubscript] += 2
        elif 5029 <= drawNum <= 6316:  # 1次抽奖
            winningMsg, winningButton = winningInformation("安慰奖", "51.52", "1次抽奖")
            freeDrawTimes[accountSubscript] += 1

        # 谢谢参与
        elif  6317 <= drawNum <= 10000:
            winningMsg, winningButton = winningInformation("谢谢参与", "无", "谢谢参与")

        # 当然了，更新账号信息后肯定要来个中奖提示嘛
        updateAccount()
        g.msgbox(msg=winningMsg, title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button=winningButton)

    def drawTenTime():
        for i in range(10):
            drawOnce()

        if len(grandPrizeList) > 0:
            grandPrize = "特等奖" + str(len(grandPrizeList)) + "个："
            for i in range(len(grandPrizeList) - 1):
                grandPrize = grandPrize + grandPrizeList[i] + "、"
            grandPrize = grandPrize + grandPrizeList[len(grandPrizeList) - 1] + "。\n"
        else:
            grandPrize = ""
        if len(firstPrizeList) > 0:
            firstPrize = "一等奖" + str(len(firstPrizeList)) + "个："
            for i in range(len(firstPrizeList) - 1):
                firstPrize = firstPrize + firstPrizeList[i] + "、"
            firstPrize = firstPrize + firstPrizeList[len(firstPrizeList) - 1] + "。\n"
        else:
            firstPrize = ""
        if len(secondPrizeList) > 0:
            secondPrize = "二等奖" + str(len(secondPrizeList)) + "个："
            for i in range(len(secondPrizeList) - 1):
                secondPrize = secondPrize + secondPrizeList[i] + "、"
            secondPrize = secondPrize + secondPrizeList[len(secondPrizeList) - 1] + "。\n"
        else:
            secondPrize = ""
        if len(thirdPrizeList) > 0:
            thirdPrize = "三等奖" + str(len(thirdPrizeList)) + "个："
            for i in range(len(thirdPrizeList) - 1):
                thirdPrize = thirdPrize + thirdPrizeList[i] + "、"
            thirdPrize = thirdPrize + thirdPrizeList[len(thirdPrizeList) - 1] + "。\n"
        else:
            thirdPrize = ""
        if len(consolationPrizeList) > 0:
            consolationPrize = "安慰奖" + str(len(consolationPrizeList)) + "个："
            for i in range(len(consolationPrizeList)-1):
                consolationPrize = consolationPrize + consolationPrizeList[i] + "、"
            consolationPrize = consolationPrize + consolationPrizeList[len(consolationPrizeList)-1] + "。\n"
        else:
            consolationPrize = ""

        allRewards = grandPrize + firstPrize + secondPrize + thirdPrize + consolationPrize + "谢谢参与：" + str(len(thankYou)) + "次"
        g.msgbox(msg="本次抽奖你获得了——\n"+allRewards, title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="确定")
        luckyDraw()

    # 这个是抽奖信息
    drawMsg = ""
    if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
        drawMsg += "福利来啦！" + startTime + "至" + endTime + "期间，幸运抽奖有几率免费！更多详情请点击首页海报。\n\n"
    drawMsg += \
           "每次抽奖需花费10个积分或一次免费抽奖次数     积分：" + str(integral[accountSubscript]) + \
        "     免费抽奖次数："+str(freeDrawTimes[accountSubscript])+"次\n\n" \
           "特等奖：（中奖率各0.08%，共0.24%）\n" \
           "518积分            VIP季卡             50次抽奖\n" \
           "一等奖：（中奖率各0.28%，共0.84%）\n" \
           "208积分            VIP月卡             30次抽奖\n" \
           "二等奖：（中奖率各0.88%，共2.64%）\n" \
           "98积分             VIP15天卡           20次抽奖\n" \
           "三等奖：（中奖率各1.98%，共7.92%）\n" \
           "38积分             18积分              VIP7天卡             10次抽奖\n" \
           "安慰奖：（中奖率各12.88%，共51.52%）\n" \
           "8积分              5积分               2积分                1次抽奖\n" \
           "谢谢参与：（几率为36.84%）\n\n" \
           "注意：\n" \
           "1、如果你抽中了VIP*卡，该卡会立即生效，延长VIP到期时间。\n" \
           "2、如果你抽中了“*次抽奖”，将会增加免费抽奖次数。\n" \
           "如果你有剩余的免费抽奖次数，下一次抽奖时就会优先使用免费抽奖次数抽奖。"

    # 抽奖主菜单
    drawOrNot = g.buttonbox(msg=drawMsg, title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", choices=("抽奖1次","抽奖10次","返回"))
    # 抽1次
    if drawOrNot == "抽奖1次":
        # 先判断积分或者是免费抽奖次数能不能抽奖
        if integral[accountSubscript] >= 10 or freeDrawTimes[accountSubscript] > 0:
            if not firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
                # 有免费抽奖次数的优先使用免费抽奖次数
                if freeDrawTimes[accountSubscript] == 0:
                    integral[accountSubscript] -= 10
                    updateAccount()
                #没有免费抽奖次数就用积分
                else:
                    freeDrawTimes[accountSubscript] -= 1
                    updateAccount()
            else:
                if r.randint(1,8) == 5:
                    g.msgbox(msg="恭喜你这次抽奖免费，无需花费任何积分或免费抽奖机会！",
                        title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="确定")
                else:
                    if freeDrawTimes[accountSubscript] == 0:
                        integral[accountSubscript] -= 10
                        updateAccount()
                    else:
                        freeDrawTimes[accountSubscript] -= 1
                        updateAccount()

            grandPrizeList = []
            firstPrizeList = []
            secondPrizeList = []
            thirdPrizeList = []
            consolationPrizeList = []
            thankYou = []
            drawOnce()
            luckyDraw()
        # 积分不够抽奖了
        else:
            g.msgbox(msg="你没有免费抽奖机会，积分也只有" + str(integral[accountSubscript]) +
            "个，无法进行抽奖。", title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="返回首页")
            my()
    # 抽10次
    elif drawOrNot == "抽奖10次":
        if freeDrawTimes[accountSubscript] >= 10:
            # 先看看有没有10次免费抽奖次数
            drawTenTimeOrNot = g.buttonbox(msg="你有"+str(freeDrawTimes[accountSubscript])+"次免费抽奖次数，"
                "是否使用10次免费抽奖次数抽奖10次？",title="图片工具" + PictureToolsEdition + "版本——幸运抽奖",choices=("确定抽奖","我再想想"))
            if drawTenTimeOrNot == "确定抽奖":
                if not firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
                    freeDrawTimes[accountSubscript] -= 10
                else:
                    if r.randint(1,40) == 10:
                        g.msgbox(msg="恭喜你这次10连抽免费，无需花费任何积分或免费抽奖机会！",
                        title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="确定")
                    else:
                        freeDrawTimes[accountSubscript] -= 10
                grandPrizeList = []
                firstPrizeList = []
                secondPrizeList = []
                thirdPrizeList = []
                consolationPrizeList = []
                thankYou = []
                drawTenTime()
                luckyDraw()
            else:
                luckyDraw()
        # 如果没有10次，但是有几次
        elif freeDrawTimes[accountSubscript] > 0:
            freeTimes = freeDrawTimes[accountSubscript]
            spendIntegral = (10 - freeTimes) * 10
            # 有积分来补
            if integral[accountSubscript] >= spendIntegral:
                drawTenTimeOrNot = g.buttonbox(msg="你只有" + str(freeTimes) + "次免费抽奖次数，"
                    "如果抽奖10次将还需要花费"+str(spendIntegral)+"个积分，是否抽奖？",
                    title="图片工具" + PictureToolsEdition + "版本——幸运抽奖",choices=("确定抽奖", "我再想想"))
                if drawTenTimeOrNot == "确定抽奖":
                    if not firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
                        integral[accountSubscript] -= (10 - freeTimes) * 10
                        freeDrawTimes[accountSubscript] = 0
                    else:
                        if r.randint(1, 30) == 10:
                            g.msgbox(msg="恭喜你这次10连抽免费，无需花费任何积分或免费抽奖机会！",
                                     title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="确定")
                        else:
                            integral[accountSubscript] -= (10 - freeTimes) * 10
                            freeDrawTimes[accountSubscript] = 0
                    grandPrizeList = []
                    firstPrizeList = []
                    secondPrizeList = []
                    thirdPrizeList = []
                    consolationPrizeList = []
                    thankYou = []
                    drawTenTime()
                    luckyDraw()
                else:
                    luckyDraw()
            # 积分不够
            else:
                g.msgbox(msg="你有" + str(freeTimes) + "次免费抽奖次数，如果抽奖10次将还需要花费" + str(spendIntegral)+ "个积分，"
                "但是你只有"+str(integral[accountSubscript])+"个积分，无法抽奖10次！",
            title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="返回抽奖页面")
                luckyDraw()
        # 最后就是没有免费次数了
        else:
            # 有100积分
            if integral[accountSubscript] >= 100:
                drawTenTimeOrNot = g.buttonbox(msg="你没有免费抽奖次数，如果抽奖10次将需要花费100个积分，是否抽奖？",
                                      title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", choices=("确定抽奖", "我再想想"))
                if drawTenTimeOrNot == "确定抽奖":
                    if not firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
                        integral[accountSubscript] -= 100
                    else:
                        if r.randint(1, 20) == 10:
                            g.msgbox(msg="恭喜你这次10连抽免费，无需花费任何积分或免费抽奖机会！",
                                     title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="确定")
                        else:
                            integral[accountSubscript] -= 100
                    grandPrizeList = []
                    firstPrizeList = []
                    secondPrizeList = []
                    thirdPrizeList = []
                    consolationPrizeList = []
                    thankYou = []
                    drawTenTime()
                    luckyDraw()
                else:
                    luckyDraw()
            # 没有100积分
            else:
                g.msgbox(msg="你没有免费抽奖次数，如果抽奖10次需要花费100个积分，但是你只有" + str(integral[accountSubscript]) +
                             "个积分，无法抽奖10次！", title="图片工具" + PictureToolsEdition + "版本——幸运抽奖", ok_button="返回抽奖页面")
                luckyDraw()
    else:
        my()

# 积分商城

def integralShop():
    # 定义函数，这样买一个商品提供一些参数就可以了
    def buyVip(spendIntegral, commodityName, time):
        #实在不想讲这些基本的东西了
        if integral[accountSubscript] >= spendIntegral:
            if g.ccbox(msg=("你有" + str(integral[accountSubscript]) + "个积分，确定要花费",
            spendIntegral, "积分购买", commodityName, "吗？"), title="图片工具——积分商城",
                choices=("确定购买", "我再想想")):
                integral[accountSubscript] -= spendIntegral
                # 如果原来是普通用户，那么比较简单
                if VIP[accountSubscript] == "ptyh":
                    VIP[accountSubscript] = (d.datetime.now() + d.timedelta(days=time)).strftime("%Y-%m-%d")
                    expirationDate = VIP[accountSubscript].split("-")
                    for i in range(len(expirationDate)):
                        expirationDate[i] = int(expirationDate[i])
                # 如果本来就是VIP那么就要先使用datetime函数根据str时间生成一个datetime的特定数据类型的时间
                else:
                    expirationDate = VIP[accountSubscript].split("-")
                    for i in range(len(expirationDate)):
                        expirationDate[i] = int(expirationDate[i])
                    VIP[accountSubscript] = (d.datetime(expirationDate[0],
            expirationDate[1], expirationDate[2]) + d.timedelta(days=time)).strftime("%Y-%m-%d")
                updateAccount()
                g.msgbox(msg=("你花费 "+str(spendIntegral)+" 积分购买了 "+str(commodityName)+" ！\n\n"
                              "剩余积分：" + str(integral[accountSubscript]) + "个\n\nVIP到期时间："
                              + str(expirationDate[0]) + "年" + str(expirationDate[1]) + "月" + str(expirationDate[2])
                              + "日"),title="图片工具" + PictureToolsEdition + "版本——积分商城", ok_button="确定")
                integralShop()
            else:
                integralShop()
        else:
            g.msgbox("你只有" + integral[accountSubscript] + "个积分，而购买" + commodityName +
                     "需要" + str(spendIntegral) + "个积分，还差" + str(spendIntegral - integral[accountSubscript])
                     + "个积分，无法购买。", title="图片工具" + PictureToolsEdition + "版本——积分商城", ok_button="确定")
            integralShop()

    # 由于这些信息太多了，所以必须先用变量来写
    VipMsg = "\n\n如果你已开通VIP，再次购买将会延后VIP到期时间\n\n"\
              "VIP用户可以获得以下特权：\n"\
              "1、首页可获得VIP用户的标识\n" \
              "3、VIP用户可以获得额外的福利\n"\
              "2、VIP用户可以抢先体验工具的测试版本和新的程序版本"

    if not firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
        if buyVipCard[accountSubscript] == "wgm":
            allCommodity = ("VIP体验卡（7天）                                                                                       48积分",
                        "VIP月卡                                                                                                    198积分",
                        "VIP季卡                                                                                                    498积分",
                        "VIP半年卡                                                                                                 888积分",
                        "VIP年卡                                                                                                    1488积分")
        else:
            allCommodity = ("VIP月卡                                                                                                    198积分",
                        "VIP季卡                                                                                                    498积分",
                        "VIP半年卡                                                                                                 888积分",
                        "VIP年卡                                                                                                    1488积分")
    else:
        if buyVipCard[accountSubscript] == "wgm":
            allCommodity = ("VIP体验卡（7天）                                                                    18积分(原价48积分)",
                        "VIP月卡                                                                                 88积分(原价198积分)",
                        "VIP季卡                                                                                 198积分(原价498积分)",
                        "VIP半年卡                                                                              418积分(原价888积分)",
                        "VIP年卡                                                                                 688积分(原价1488积分)")
        else:
            allCommodity = ("VIP月卡                                                                                 88积分(原价198积分)",
                        "VIP季卡                                                                                 198积分(原价498积分)",
                        "VIP半年卡                                                                              418积分(原价888积分)",
                        "VIP年卡                                                                                 688积分(原价1488积分)")

    shopMsg = ""
    if firstEventTime[0] <= str(d.datetime.now().strftime('%Y-%m-%d')) <= firstEventTime[1]:
        shopMsg += "福利来啦！" + startTime + "至" + endTime + "期间，幸运抽奖有几率免费！更多详情请点击首页海报。\n\n"
    shopMsg += "剩余积分：" + str(integral[accountSubscript]) + VipMsg
    buy = g.choicebox(msg=shopMsg,title="图片工具" + PictureToolsEdition + "版本——积分商城",choices=allCommodity)
    # 你看，有了前面的函数，购买就很简单了
    if buy == "VIP体验卡（7天）                                                                                       48积分":
        buyVipCard[accountSubscript] = "ygm"
        buyVip(48,"VIP体验卡（7天）",7)
    elif buy == "VIP月卡                                                                                                    198积分":
        buyVip(198,"VIP月卡",31)
    elif buy == "VIP季卡                                                                                                    498积分":
        buyVip(498, "VIP季卡", 92)
    elif buy == "VIP半年卡                                                                                                 888积分":
        buyVip(888, "VIP半年卡", 183)
    elif buy == "VIP年卡                                                                                                    1488积分":
        buyVip(1488, "VIP年卡", 365)
    elif buy == "VIP体验卡（7天）                                                                    18积分(原价48积分)":
        buyVip(18, "VIP体验卡（7天）", 7)
    elif buy == "VIP月卡                                                                                 88积分(原价198积分)":
        buyVip(88, "VIP月卡", 31)
    elif buy == "VIP季卡                                                                                 198积分(原价498积分)":
        buyVip(198, "VIP季卡", 92)
    elif buy == "VIP半年卡                                                                              418积分(原价888积分)":
        buyVip(418, "VIP半年卡", 183)
    elif buy == "VIP年卡                                                                                 688积分(原价1488积分)":
        buyVip(688, "VIP年卡", 365)
    else:
        my()

'''
设置
'''
def settings():
    settingOperation = g.buttonbox(msg="图片工具（PictureTools）" + PictureToolsEdition + "版本\n作者邮箱：lxf20070918@126.com",
    title="图片工具" + PictureToolsEdition + "版本——设置", choices=("☜我的", "账号设置", "邮箱设置", "通用设置", "关于图片工具"))
    if settingOperation == "☜我的":
        my()
    elif settingOperation == "账号设置":
        accountSettings()
    elif settingOperation == "邮箱设置":
        emailSettings()
    elif settingOperation == "通用设置":
        generalSettings()
    elif settingOperation == "关于图片工具":
        aboutPictureTool()

# 账号设置
def accountSettings():
    emailSettingsOperation = g.buttonbox(msg="账号：" + accountNums[accountSubscript],
    title="图片工具" + PictureToolsEdition + "版本——账号设置", choices=("注销账号", "退出登录", "返回"))
    if emailSettingsOperation == "注销账号":
        cancelAccount()
    elif emailSettingsOperation == "退出登录":
        if g.ccbox(msg="确定退出登录吗？", title="图片工具" + PictureToolsEdition + "版本——退出登录", choices=("确定", "取消")):
            start()
        else:
            accountSettings()
    elif emailSettingsOperation == "返回":
        settings()

# 注销账号
def cancelAccount():
    if accountNums[accountSubscript] == "ptyh":
        cancelMsg = "你确定要注销你的账号——" + accountNums[accountSubscript] + " 吗？"
    else:
        cancelMsg = "你确定要注销你的VIP账号：" + accountNums[accountSubscript] + " 吗？"
    if g.ccbox(msg=cancelMsg, title="图片工具" + PictureToolsEdition + "版本——注销账号", choices=("我再想想", "确定")):
        accountSettings()
    else:
        input = g.passwordbox(msg="请输入你的密码：\n"
                              "（如果你忘记了密码，请退出登录后点击忘记密码修改密码）",
                    title="图片工具" + PictureToolsEdition + "版本——注销账号")
        if input != None:
            if input == passwords[accountSubscript]:
                yourAccount = accountNums[accountSubscript]
                accountNums.pop(accountSubscript)
                passwords.pop(accountSubscript)
                integral.pop(accountSubscript)
                freeDrawTimes.pop(accountSubscript)
                signInInfor.pop(accountSubscript)
                VIP.pop(accountSubscript)
                buyVipCard.pop(accountSubscript)
                email.pop(accountSubscript)
                firstEvent.pop(accountSubscript)
                updateAccount()
                g.msgbox(msg="你成功注销了你的账号：" + yourAccount + "。",
                title="图片工具" + PictureToolsEdition + "版本——注销账号", ok_button="确定")
            else:
                g.msgbox(msg="密码输入错误。", title="图片工具" + PictureToolsEdition +
                                "版本——注销账号", ok_button="确定")
                accountSettings()
        else:
            accountSettings()


# 邮箱设置
def emailSettings():
    if email[accountSubscript] != "wbd":
        emailSettingsMsg = "绑定的邮箱：" + email[accountSubscript]
    else:
        emailSettingsMsg = "绑定的邮箱：未绑定邮箱"
    emailSettingsOperation = g.buttonbox(msg=emailSettingsMsg, title="图片工具" + PictureToolsEdition + "版本——邮箱设置",
    choices=("绑定邮箱", "解绑邮箱", "返回"))
    if emailSettingsOperation == "绑定邮箱":
        if email[accountSubscript] == "wbd":
            bindEmail(accountSubscript, "登录")
        else:
            g.msgbox(msg="你已经绑定了邮箱"+email[accountSubscript]+"，无法再次绑定，如果你想要绑定新的邮箱，可以先"
                        "在设置中解绑邮箱，在绑定新的邮箱",title="图片工具" + PictureToolsEdition +
                                    "版本——绑定邮箱",ok_button="好的，我知道了")
            settings()
    elif emailSettingsOperation == "解绑邮箱":
        if email[accountSubscript] != "wbd":
            unbindEmail()
        else:
            g.msgbox(msg="你还没有绑定邮箱哦，无法解绑。", title="图片工具" + PictureToolsEdition + "版本——解绑邮箱"
            + PictureToolsEdition + "版本——解绑邮箱", ok_button="好的，我知道了")
            settings()
    elif emailSettingsOperation == "返回":
        settings()

# 绑定邮箱
def bindEmail(subscript, state):
    def cancelBind():
        if state == "注册":
            g.msgbox(msg="如果你想绑定邮箱，请到设置——绑定邮箱，如果没有绑定邮箱，忘记密码时将无法修改密码。",
                     title="图片工具" + PictureToolsEdition + "版本——绑定邮箱", ok_button="好的")
            signInError = ""
            signInTips = ["", ""]
            signIn(signInError, signInTips)
        else:
            g.msgbox(msg="如果你想绑定邮箱，请到设置——绑定邮箱，如果没有绑定邮箱，忘记密码时将无法修改密码。",
                     title="图片工具" + PictureToolsEdition + "版本——绑定邮箱", ok_button="好的")
            emailSettings()

    def emailInputError():
        g.msgbox(msg="输入邮箱错误，请输入正确的邮箱！", title="图片工具" + PictureToolsEdition + "版本——绑定邮箱", ok_button="重新绑定")
        if state == "注册":
            bindEmail(accountNums.index(registerAccount), "注册")
        else:
            bindEmail(accountSubscript, "登录")

    def sendVerificationCode(error):
        verificationCodeInput = g.enterbox(msg="已向你的邮箱" + emailInput + "发送了验证码，请查收邮件并输入你收到的验证码：" + error, title="图片工具——绑定邮箱")
        if verificationCodeInput != None:
            if verificationCodeInput == str(verificationCode):
                email[subscript] = emailInput
                updateAccount()
                if state == "注册":
                    g.msgbox(msg="你成功绑定了邮箱" + emailInput + "！", title="图片工具" + PictureToolsEdition +
                                                        "版本——绑定邮箱", ok_button="立即登录")
                    signInError = ""
                    signInTips = ["", ""]
                    signIn(signInError,signInTips)
                else:
                    g.msgbox(msg="你成功绑定了邮箱" + emailInput + "！", title="图片工具" + PictureToolsEdition +
                                                        "版本——绑定邮箱", ok_button="返回")
                    emailSettings()
            else:
                verificationCodeError = "\n\n验证码输入错误，请再次输入！"
                sendVerificationCode(verificationCodeError)
        else:
            cancelBind()

    emailInput = g.enterbox(msg="请输入你常用的邮箱地址：\n"
                           "点击确定后图片工具将会向你的邮箱发送验证码，发送过程可能需要几秒的时间，请耐心等待！\n"
                           "（仅支持网易163、126、yeah邮箱）", title="图片工具" + PictureToolsEdition + "版本——绑定邮箱")
    if emailInput != None:
        if "@" in emailInput:
            if emailInput.endswith("163.com") or emailInput.endswith("126.com") or emailInput.endswith("yeah.net"):
                if not emailInput in email:
                    verificationCode = ""
                    for i in range(3):
                        verificationCode += str(r.randint(10, 99))
                    emailMsg = "你正在图片工具绑定邮箱，验证码为：" + verificationCode + "，若非你本人操作，请忽略此消息。"
                    if sendEmail("smtp.qq.com", "2563007197@qq.com", "ehlnaixgakghebij", emailInput, "图片工具绑定邮箱验证码", emailMsg):
                        verificationCodeError = ""
                        sendVerificationCode(verificationCodeError)
                    else:
                        g.msgbox(msg="发送邮件错误，请检查你输入的邮箱是否正确，如果正确依然还发送失败，你可以联系作者修复软件问题。", title="图片工具——绑定邮箱", ok_button="重新绑定")
                        if state == "注册":
                            bindEmail(accountNums.index(registerAccount), "注册")
                        else:
                            bindEmail(accountSubscript, "登录")
                else:
                    g.msgbox(msg="已经有用户绑定了此邮箱！",
                    title="图片工具"+ PictureToolsEdition + "版本——绑定邮箱", ok_button="重新绑定")
                    if state == "注册":
                        bindEmail(accountNums.index(registerAccount), "注册")
                    else:
                        bindEmail(accountSubscript, "登录")
            else:
                emailInputError()
        else:
            emailInputError()
    else:
        cancelBind()

# 解绑邮箱
def unbindEmail():
    if g.ccbox(msg="你确定要解绑你的邮箱"+email[accountSubscript]+"吗？解绑后将无法使用忘记密码功能。",
               title="图片工具" + PictureToolsEdition + "版本——解绑邮箱", choices=("确定", "取消")):
        def sendVerificationCode(error):
            verificationCodeInput = g.enterbox(msg="已向你的邮箱" + email[accountSubscript] +
                    "发送了验证码，请查收邮件并输入你收到的验证码：" + error,
                    title="图片工具" + PictureToolsEdition + "版本——解绑邮箱")
            if verificationCodeInput == str(verificationCode):
                g.msgbox(msg="你成功解绑了邮箱" + email[accountSubscript] + "！",
                         title="图片工具" + PictureToolsEdition + "版本——解绑邮箱", ok_button="返回")
                email[accountSubscript] = "wbd"
                updateAccount()
                emailSettings()
            else:
                VerificationCodeError = "\n\n验证码输入错误，请再次输入！"
                sendVerificationCode(VerificationCodeError)

        verificationCode = ""
        for i in range(3):
            verificationCode += str(r.randint(10, 99))
        emailMsg = "你正在图片工具解绑邮箱，验证码为：" + verificationCode + "，若非你本人操作，请忽略此消息。"
        if sendEmail("smtp.qq.com", "2563007197@qq.com", "ehlnaixgakghebij", email[accountSubscript], "图片工具解绑邮箱验证码", emailMsg):
            verificationCodeError = ""
            sendVerificationCode(verificationCodeError)
        else:
            g.msgbox(msg="发送邮件错误，请检查你输入的邮箱是否正确，如果正确依然还发送失败，你可以联系作者修复软件问题。",
                     title="图片工具" + PictureToolsEdition + "版本——解绑邮箱", ok_button="重新解绑")
            unbindEmail()
    else:
        emailSettings()


# 通用设置
def generalSettings():
    if city[accountSubscript] != "wsz":
        generalSettingsMsg = "设置的城市：" + city[accountSubscript]
    else:
        generalSettingsMsg = "设置的城市：未设置城市"

    generalSettingsOperation = g.buttonbox(msg=generalSettingsMsg,
    title="图片工具" + PictureToolsEdition + "版本——通用设置", choices=("设置城市", "返回"))

    if generalSettingsOperation == "设置城市":
        setUpCity(accountSubscript)
        generalSettings()
    elif generalSettingsOperation == "返回":
        settings()

# 设置城市
def setUpCity(subscript):
    MDUCG = ["北京", "天津", "上海", "重庆"]

    SAR = ["香港", "澳门"]

    f = open("AllCity.txt", encoding="utf-8")
    allCity = json.loads(f.read())
    f.close()

    choiceProvince = g.choicebox(msg="请选择你所在的省份（直辖市、自治区、特别行政区）：",
                title="图片工具" + PictureToolsEdition + "版本——设置城市",
                choices=(list(allCity.keys()) + MDUCG + SAR))
    if choiceProvince != None:
        if not choiceProvince in MDUCG and not choiceProvince in SAR:
            choiceCity = g.choicebox(msg="请选择你在省份“" + choiceProvince + "”的哪一个城市：",
                                     title="图片工具" + PictureToolsEdition + "版本——设置城市",
                                     choices=allCity[choiceProvince])
            if choiceCity != None:
                city[subscript] = choiceCity
                updateAccount()
            else:
                setUpCity(subscript)
        else:
            city[subscript] = choiceProvince
            updateAccount()
    else:
        if city[accountSubscript] == "wsz":
            g.msgbox(msg="不选择你所在的城市将无法在首页看到你所在位置的天气信息，建议你设置所在城市，如果你想设置所在城市，"
                         "可以到设置——通用设置中寻找。", title="图片工具" + PictureToolsEdition + "版本——设置城市",
                     ok_button="好的")


# 关于图片工具
def aboutPictureTool():
    global latestVersion, LVDownloadWay, LVGitHubUrl, LVBaiDuUrl, LVBaiDuPassword
    aboutPictureToolOperation = g.buttonbox(msg="图片工具版本：" + PictureToolsEdition + "版本",
    title="图片工具" + PictureToolsEdition + "版本——关于图片工具", choices=("声明", "更新日志", "介绍与概况", "检查更新", "卸载图片工具", "返回"))
    if aboutPictureToolOperation == "声明":
        f = open("statement.txt", "r", encoding="utf-8")
        statement = f.read()
        f.close()
        if g.msgbox(msg=statement, title="图片工具" + PictureToolsEdition + "版本——关于图片工具", ok_button="返回") == "返回":
            aboutPictureTool()
    elif aboutPictureToolOperation == "更新日志":
        updateLog()
        aboutPictureTool()
    elif aboutPictureToolOperation == "介绍与概况":
        writeClipboard("tpgj")
        if g.ccbox(msg="《图片工具》的介绍与概况为另外程序，大小约547MB。点击“确定”打开百度网盘链接下载，已将提取码“tpgj”"
                       "复制到剪切板。", title="图片工具" + PictureToolsEdition + "——检查更新", choices=["确定", "取消"]):
            web.open_new("https://pan.baidu.com/s/1TznA7DKpYLlzWnG2fQ6VUQ")
        aboutPictureTool()
    elif aboutPictureToolOperation == "检查更新":
        if internetAccess():
            # 获取最新版本、最新版本下载链接和最新版本提取码
            latestVersion, LVDownloadWay, LVGitHubUrl, LVBaiDuUrl, LVBaiDuPassword = getLastVersion()
        else:
            latestVersion = "未连接网络"

        if PictureToolsEdition != latestVersion and latestVersion != "未连接网络":
            if g.ccbox(msg="当前最新版本为" + latestVersion + "版本，建议你安装最新版本的图片工具。",
                    title="图片工具" + PictureToolsEdition + "——检查更新", choices=("下载最新版本", "暂不下载")):
                if LVDownloadWay == "GitHub下载":
                    try:
                        isDownload = True
                        downloadLastVersion(LVGitHubUrl)
                    except Exception:
                        isDownload = False
                        g.msgbox(msg="无法连接网络，" + latestVersion + "版本下载失败，请确认联网或稍后再试。",
                                 title="图片工具" + PictureToolsEdition + "——检查更新", ok_button="确定")
                        homePage()
                    if isDownload == True:
                        g.msgbox(msg="图片工具" + latestVersion + "版本安装成功，即将卸载此版本图片工具，请在卸载后打开最新版本的图片工具。",
                                 title="图片工具" + PictureToolsEdition + "——检查更新", ok_button="卸载")
                        Remove.remove(PictureToolsEdition)
                else:
                    writeClipboard(LVBaiDuPassword)
                    if g.msgbox(msg="由于无法直接连接下载，将为你打开百度网盘下载网页自行下载，已将提取码“" + LVBaiDuPassword + "”"
                "复制到剪切板。点击“确定”打开。", title="图片工具" + PictureToolsEdition + "——检查更新", ok_button="确定") == "确定":
                        web.open_new(LVBaiDuUrl)
            else:
                aboutPictureTool()
        else:
            if latestVersion == "未连接网络":
                g.msgbox(msg="你没有连接到网络，无法检查更新，请确认联网或稍后再试。", title="图片工具" + PictureToolsEdition + "——检查更新",
                         ok_button="确定")
            else:
                g.msgbox(msg="你已将图片工具升级到了最新版本：" + latestVersion + "版本。", title="图片工具" +
                        PictureToolsEdition + "——检查更新", ok_button="确定")
            aboutPictureTool()
    elif aboutPictureToolOperation == "卸载图片工具":
        if not g.ccbox(msg="你确定要卸载图片工具吗？", title="图片工具" + PictureToolsEdition + "版本——卸载软件", choices=("我再想想", "狠心卸载")):
            Remove.remove(PictureToolsEdition)
        else:
            aboutPictureTool()
    elif aboutPictureToolOperation == "返回":
        settings()

'''
开始界面
'''

def start():
    startOperation = g.buttonbox(msg = "欢迎使用使用《图片工具》，登录后就可使用各个图片小工具了！\n\n"
                              "还没有账号？点击注册！",
                            title = "图片工具——" + PictureToolsEdition + "版本",choices=("登录","注册","忘记密码"))
    if startOperation == "登录":
        signInError = ""
        signInTips = ["", ""]
        signIn(signInError,signInTips)
    elif startOperation == "注册":
        global registerError
        registerError = ""
        registerTips = ["", "", ""]
        register(registerTips)
    elif startOperation == "忘记密码":
        newPasswordError = ""
        forgetPassword(newPasswordError)


'''
START!
'''

if __name__ == "__main__":
    start()