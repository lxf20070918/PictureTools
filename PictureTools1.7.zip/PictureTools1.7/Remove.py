import os
import shutil
import easygui as g
def remove(Edition):
    path = os.getcwd()
    allFile = os.listdir()
    allFile.remove("Remove.py")
    for i in allFile:
        try:
            os.remove(i)
        except Exception:
            shutil.rmtree(i)
    g.msgbox(msg="图片工具卸载成功，期待与你的下一次相遇", title="图片工具" + Edition + "版本——卸载软件", ok_button="再见")
    try:
        os.remove(path)
    except Exception:
        try:
            shutil.rmtree(path)
        except Exception:
            pass
    exit()

