def PictureZoom1_1():
    global imgPath, width, height, zoomSize, msg2, rewardIntegral
    imgPath = "."
    width = 0
    height = 0
    zoomSize = 1
    msg2 = ""
    rewardIntegral = 0

    # 导入模块：

    import easygui as g
    from PIL import Image
    import os
    import random as r
    import imghdr

    def excludingChinese(str):
        for i in str:
            if "\u4e00" <= i <= "\u9fff":
                return False
        return True

    def updateWH():
        global width, height
        width, height = Image.open("PictureZoomCache.png").size

    def openImg():
        global imgPath
        openPath = g.fileopenbox(msg="图片缩放1.1版本——打开图片", default="C:\\Users\\Administrator\\Desktop\\*.png")
        if openPath != ".":
            if imghdr.what(openPath):
                imgPath = openPath
                f = open(imgPath, "rb")
                n = f.read()
                f.close()

                f = open("PictureZoomCache.png", "wb")
                f.write(n)
                f.close()
                Image.open("PictureZoomCache.png").size
                updateWH()
                global beforZoomWidth, beforZoomHeight
                beforZoomWidth, beforZoomHeight = Image.open(imgPath).size
                img2 = ""
                homePage(img2)
            else:
                g.msgbox(msg="无法打开你选择的文件。", title="图片缩放1.1版本——错误", ok_button="重新打开")
                openImg()
        else:
            img2 = ""
            homePage(img2)

    def zoomImg(afterWidth, afterHeight):
        global width, height
        img = Image.open(imgPath)
        # 设置缩放后的宽高
        img = img.resize((int(afterWidth), int(afterHeight)))
        # 保存图片（这里先保存到了程序所在的文件夹中，其实只是一个缓存，下一步讲）
        img.save("PictureZoomCache.png", "png")
        updateWH()

    def inputWH(error):
        global zoomSize
        input = g.multenterbox(msg="请输入缩放后的宽和高：" + error, title="图片缩放1.1版本——输入宽高", fields=("宽", "高"), values=("", ""))
        if input != None:
            inputWidth, inputHeigh = input[0], input[1]
            if inputWidth.isalnum() and excludingChinese(inputWidth) and inputHeigh.isdigit() and excludingChinese(inputHeigh):
                zoomImg(inputWidth, inputHeigh)
                msg2 = ""
                updateWH()
                zoomSize = "--"
                homePage(msg2)
            else:
                inputWHError = "\n\n错误：输入的宽高需为整数"
                inputWH(inputWHError)
        else:
            msg2 = ""
            homePage(msg2)

    def inputPercentage(error):
        global zoomSize
        input = g.enterbox(msg="请输入缩放百分比：（如50%，200%）" + error, title="图片缩放1.1版本——输入百分比")
        if input != None:
            if "%" in input and len(input.split("%")) == 2 and input.split("%")[1] == "" and \
                    input.split("%")[0].isdigit() and excludingChinese(input.split("%")[0]) and int(input.split("%")[0]) > 0:
                zoomSize = int(input.split("%")[0]) / 100
                zoomImg(width * zoomSize, height * zoomSize)
                updateWH()
                img2 = ""
                homePage(img2)
            else:
                inputPercentageError = "\n\n错误：请输入正确的百分比"
                inputPercentage(inputPercentageError)
        else:
            img2 = ""
            homePage(img2)

    def homePage(otherMsg):
        global imgPath, zoomSize, width, height
        msg = "图片："
        if imgPath != ".":
            if zoomSize != "--":
                msg += imgPath + "\n当前大小：" + str(zoomSize * 100).split(".")[0] + "%"
            else:
                msg += imgPath + "\n当前大小：--%"
            msg += "          当前的宽：" + str(width) + "像素          当前的高：" + str(height) + "像素" + otherMsg
            img = "PictureZoomCache.png"
        else:
            msg += "未打开图片。" + otherMsg
            img = "Image\\Img2.png"

        Operation = g.buttonbox(msg=msg, image=img, title="图片缩放——1.1版本",
                    choices=("缩小-", "放大+", "输入宽高", "输入百分比", "保存图片"))
        if Operation == "缩小-":
            if imgPath != ".":
                try:
                    if zoomSize == "--":
                        zoomSize = 0.9
                    else:
                        zoomSize -= 0.1
                    zoomImg(beforZoomWidth * zoomSize, beforZoomHeight * zoomSize)
                    msg2 = ""
                    homePage(msg2)
                except Exception:
                    zoomSize += 0.1
                    msg2 = "\n\n错误：无法再次进行缩小"
                    homePage(msg2)
            else:
                msg2 = "\n\n错误：未打开图片"
                homePage(msg2)

        elif Operation == "放大+":
            if imgPath != ".":
                if zoomSize == "--":
                    zoomSize = 0.9
                else:
                    zoomSize += 0.1
                zoomImg(beforZoomWidth * zoomSize, beforZoomHeight * zoomSize)
                img2 = ""
                homePage(img2)
            else:
                img2 = "\n\n错误：未打开图片"
                homePage(img2)
        elif Operation == "输入宽高":
            if imgPath != ".":
                inputWHError = ""
                inputWH(inputWHError)
            else:
                msg2 = "\n\n错误：未打开图片"
                homePage(msg2)
        elif Operation == "输入百分比":
            if imgPath != ".":
                inputPercentageError = ""
                inputPercentage(inputPercentageError)
            else:
                img2 = "\n\n错误：未打开图片"
                homePage(img2)
        elif Operation == "保存图片":
            if imgPath != ".":
                imgName = imgPath.split("\\")[len(imgPath.split("\\"))-1].split(".")[0]
                savePath = g.filesavebox(msg="图片缩放1.1版本——保存图片",
                default="C:\\Users\\Administrator\\Desktop\\" + imgName + "_图片缩放.png")
                if savePath != None:
                    f = open("PictureZoomCache.png", "rb")
                    n = f.read()
                    f.close()

                    os.remove("PictureZoomCache.png")

                    f = open(savePath, "wb")
                    f.write(n)
                    f.close()

                    global rewardIntegral
                    rewardIntegral = r.randint(3, 6)
                    g.msgbox(msg="你成功保存了缩放的图片，奖励你" + str(rewardIntegral) + "个积分。",
                             title="图片缩放1.1版本——奖励积分", ok_button="收下并返回工具")
                else:
                    img2 = ""
                    homePage(img2)
            else:
                img2 = "\n\n错误：未打开图片"
                homePage(img2)
        elif Operation == "PictureZoomCache.png" or Operation == "Image\\Img2.png":
            openImg()

        else:
            if img == "PictureZoomCache.png":
                os.remove("PictureZoomCache.png")

    openImg()
    return rewardIntegral