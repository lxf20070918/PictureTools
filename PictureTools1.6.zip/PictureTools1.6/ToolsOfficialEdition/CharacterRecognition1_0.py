def CharacterRecognition1_0():
    from aip import AipOcr
    import easygui as g
    import win32clipboard as w
    import os
    from PIL import ImageGrab
    from PIL import Image
    import random as r
    global rewardIntegral
    global rewardIntegral
    rewardIntegral = 0

    def 写入剪切板(aString):#写入剪切板
        w.OpenClipboard()
        w.EmptyClipboard()
        w.SetClipboardText(aString)
        w.CloseClipboard()

    def 识别(图片):
        global rewardIntegral
        APP_ID = '19491707'
        API_KEY = 'PsdojrGMXXbGaOBGf7mtPVX8'
        SECRET_KEY = 'CFLzrzCiF4YYOS8bdKdBLM8PeXUlKe2M'

        client = AipOcr(APP_ID, API_KEY, SECRET_KEY)

        text = client.basicAccurate(图片)

        文字 = (list(text.items())[2])[1]
        识别结果 = ""
        for i in 文字:
            识别结果 += i["words"] + "\n"

        Operation = g.buttonbox(msg="识别结果：\n\n\n" + 识别结果, title="文字识别1.0版本——识别结果", choices=("保存为txt文件", "复制到剪切板"))
        if Operation == "保存为txt文件":
            f = open(r"文字识别.txt", "w")
            f.write(识别结果)
            f.close()
            g.msgbox(msg="保存成功，请到程序所在文件夹查看。", title="文字识别1.0版本——保存成功", ok_button="确定")

        elif Operation == "复制到剪切板":
            写入剪切板(识别结果)
            g.msgbox(msg="已将识别结果复制到剪切板。", title="文字识别1.0版本——复制成功", ok_button="确定")

        rewardIntegral = r.randint(3, 6)
        g.msgbox(msg="你成功识别了图片，奖励你" + str(rewardIntegral) + "个积分。",
                 title="文字识别1.0版本——奖励积分", ok_button="收下并返回工具")

    获取方式 = g.buttonbox(msg="如何获取你想要识别的图片\n（如果你只是使用了截屏工具截取了图片，你可以选择“从剪切板获取”）",
                       title="文字识别1.0版本——获取图片", choices=("打开本地图片", "从剪切板获取"))

    if 获取方式 == "打开本地图片":
        打开路径 = g.fileopenbox()
        if 打开路径 != ".":
            try:
                with open(打开路径, 'rb') as f:
                    图片 = f.read()
                try:
                    识别(图片)
                except Exception:
                    return "网络错误"
            except Exception:
                g.msgbox(msg="无法打开此图片，可能是图片格式错误或图片已损坏。", title="文字识别1.0版本——错误", ok_button="确定")

    elif 获取方式 == "从剪切板获取":
        try:
            img = ImageGrab.grabclipboard()
            if isinstance(img, Image.Image):
                img.save("截屏缓存.png", "png")

            f = open("截屏缓存.png", "rb")
            图片 = f.read()
            f.close()

            os.remove("截屏缓存.png")

            try:
                识别(图片)
            except Exception:
                return "网络错误"

        except Exception:
            g.msgbox(msg="无法获取剪切板的图片，请确认你已截图。", title="文字识别1.0版本——错误", ok_button="确定")

    return rewardIntegral
