def PictureSearch1_0():
    import requests
    import os
    import easygui as g
    import random as r
    global rewardIntegral

    rewardIntegral = 0

    searchCachePath = os.getcwd()
    searchCachePath = searchCachePath.split("\\")
    searchCachePathCache = ""
    for i in searchCachePath:
        searchCachePathCache += i + "/"
    searchCachePath = searchCachePathCache + "SearchCache/"

    def delAllFile(folderPath):
        import os
        fileName = os.listdir(folderPath)
        for i in fileName:
            filePath = os.path.join(folderPath, i)
            os.remove(filePath)

    try:
        def excludingChinese(str):
            for i in str:
                if "\u4e00" <= i <= "\u9fff":
                    return False
            return True

        def getUrls(keyword, pages):
            params = []
            params.append({
            'tn':'resultjson_com',
            'ipn':'rj',
            'ct':201326592,
            'is':'',
            'fp':'result',
            'queryWord':keyword,  # 关键词
            'cl':2,
            'lm':-1,
            'ie':'utf-8',
            'oe':'utf-8',
            'adpicid':'',
            'st':-1,
            'z':'',
            'ic':0,
            'word':keyword,  # 关键词
            's':'',
            'se':'',
            'tab':'',
            'width':'',
            'height':'',
            'face':0,
            'istype':2,
            'qc':'',
            'nc':1,
            'fr':'',
            'pn':pages, # 取数量
            'rn':pages,
            'gsm':'le',
            '1488942260214':''
            })
            url = "https://image.baidu.com/search/acjson"
            urls = []
            for i in params:
                urls.append(requests.get(url, params=i).json()["data"])
            return urls

        def getImg(urlList, path):
            if not os.path.exists(path):
                os.mkdir(path)
            x = 0
            allPath = []
            for list in urlList:
                for i in list:
                    if len(i) != 0:
                        x += 1
                        data = requests.get(i['thumbURL'])
                        open(path+str(x)+".jpg", "wb").write(data.content)
                        allInfo = {
                            "path":"/static/"+str(x)+".jpg",
                            "width":i["width"],
                            "height":i["height"],
                            "name":str(x)+".jpg",
                            "fullpath":searchCachePath+str(x)+".jpg",
                        }
                        allPath.append(allInfo)

        def changeNum(imgNum):
            imgPath = searchCachePath + str(imgNum) + ".jpg"
            if imgNum == len(imgList):
                choices = ["上一张", "保存"]
            elif imgNum == 1:
                choices = ["保存", "下一张"]
            else:
                choices = ["上一张", "保存", "下一张"]
            operation = g.buttonbox(msg="关键词“" + keyword + "”的搜索结果：",image=imgPath,title="图片搜索1.0版本——搜索结果", choices=choices)
            if operation == "上一张":
                imgNum -= 1
                changeNum(imgNum)
            elif operation == "下一张":
                imgNum += 1
                changeNum(imgNum)
            elif operation == "保存":
                saveImg = open(imgPath, "rb").read()
                savePath = g.filesavebox(title="图片搜索1.0版本——保存图片", default=str(imgNum) + ".jpg")
                if savePath != None:
                    f = open(savePath, "wb")
                    f.write(saveImg)
                    f.close()
                    changeNum(imgNum)
                else:
                    changeNum(imgNum)
            elif operation == imgPath:
                changeNum(imgNum)
            else:
                delAllFile(searchCachePath)

                global rewardIntegral
                rewardIntegral = r.randint(3, 6)
                g.msgbox(msg="你成功搜索到了图片，奖励你" + str(rewardIntegral) + "个积分。",
                         title="图片搜索1.0版本——奖励积分", ok_button="收下并返回工具")


        input = g.multenterbox(msg="请输入关键词和爬取张数", title="图片搜索——1.0版本", fields=("关键词", "爬取张数"))
        if input != None:
            keyword, pages = input[0], input[1]
            if pages.isdigit() and excludingChinese(pages) and int(pages) > 0:
                pages = int(pages)
                urlList = getUrls(keyword, pages)
                getImg(urlList, searchCachePath)

                getImgListPath = list(searchCachePath)
                getImgListPath.pop(len(getImgListPath) - 1)
                getImgListPathCache = ""
                for i in getImgListPath:
                    getImgListPathCache += i
                getImgListPath = getImgListPathCache

                imgList = os.listdir(getImgListPath)
                imgNum = 1

                changeNum(imgNum)
            else:
                g.msgbox(msg="爬取张数需为整数", title="图片搜索1.0版本——错误", ok_button="确定")

        return rewardIntegral

    except Exception:
        if os.listdir(searchCachePath) != []:
            delAllFile(searchCachePath)
        return "网络错误"