def 字体图片工具1_0正式版():# 此为图片工具的小程序之一，定义字体图片工具()

    # 导入模块：

    #easygui用于界面的显示
    import easygui as g

    #pygame用于字体图片的主要工作
    import pygame

    #random模块用于取随机数
    import random as r

    def 背景颜色输入错误():
        global 奖励积分
        g.msgbox(msg="背景颜色输入错误！", title="字体图片工具", ok_button="返回首页")

    def 文字颜色输入错误():
        g.msgbox(msg="文字颜色输入错误！", title="字体图片工具", ok_button="返回首页")

    def 转化为元组(字符串):
        列表 = 字符串.split(",")
        下标 = -1
        for i in 列表:
            下标 += 1
            列表[下标] = int(列表[下标])
        return 列表

    pygame.init()

    标准颜色 = ["红色", "橙色", "黄色", "绿色", "青色", "蓝色", "紫色", "灰色", "粉红", "黑色", "白色", "棕色"]
    标准颜色rgb = [(255,0,0),(255,97,0),(255,255,0),(0,255,0),(0,255,255),(0,0,255),(255,0,255),(192,192,192),(249,204,226),(0,0,0),(255,255,255),(128,42,42)]
                  #红色       橙色       黄色       绿色       青色        蓝色      紫色        灰色           粉红          黑色    白色           棕色
    # 注意事项
    注意事项 = "欢迎使用《字体图片工具1.0正式版》，操作程序请注意：\n" \
              "1、程序功能为将使用导出字体的文字，导出的文件为图片；\n" \
              "2、程序仅支持部分字体的文字导出；\n" \
              "3、输入文字时请与你选择的字体匹配，否则输出的图片会错；\n" \
              "4、输入文字颜色时可以输入“红、橙、黄、绿、青、蓝、紫、灰、粉红、黑、白、棕“这\n" \
              "   些常用颜色或者是“红、绿、蓝”这三个颜色的值（rgb），值为0-255之间的整数。\n" \
              "5、成功使用程序后可获得1-2个积分。"

    g.msgbox(msg=注意事项, title="字体图片工具", ok_button="我已仔细阅读")

    字体库 = pygame.font.get_fonts()
    字体库.insert(114,"宋体中文")
    字体 = g.choicebox(msg="请选择你想要使用的字体", title="字体图片工具", choices=字体库)
    if 字体 != None:
        文字 = g.enterbox(msg="请输入你想要保存的文字", title="字体图片工具")
        print(文字,type(文字))
        大小 = g.enterbox(msg="请输入文字的大小", title="字体图片工具")
        if 大小 != None and 大小.isdigit() and int(大小) > 0:
            大小 = int(大小)
            文字颜色 = g.enterbox(msg="请输入文字颜色", title="字体图片工具")
            if 文字颜色 in 标准颜色:
                下标 = 标准颜色.index(文字颜色)
                文字颜色 = 标准颜色rgb[下标]
                rgb错误 = False
            elif "," in 文字颜色:
                rgb = 文字颜色.split(",")
                for i in range(len(rgb)):
                    if rgb[i].isdigit():
                        rgb[i] = int(rgb[i])
                    else:
                        rgb错误 = True
                        break
                if not rgb错误:
                    rgb错误 = False
            if not rgb错误:
                if len(rgb) == 3 and rgb[0] > -1 and rgb[1] > -1 and rgb[2] > -1 and rgb[0] < 256 and rgb[1] < 256 and rgb[2] < 256:
                    文字颜色 = 转化为元组(文字颜色)
                    背景颜色 = g.enterbox(msg="请输入背景颜色", title="字体图片工具")
                    if 背景颜色 in 标准颜色:
                        下标 = 标准颜色.index(背景颜色)
                        背景颜色 = 标准颜色rgb[下标]
                        rgb错误 = False
                    elif "," in 背景颜色:
                        rgb = 背景颜色.split(",")
                        for i in range(len(rgb)):
                            if rgb[i].isdigit():
                                rgb[i] = int(rgb[i])
                            else:
                                rgb错误 = True
                                break
                        if not rgb错误:
                            rgb错误 = False
                        if not rgb错误:
                            if len(rgb) == 3 and rgb[0] > -1 and rgb[1] > -1 and rgb[2] > -1 and rgb[0] < 256 and \
                                    rgb[1] < 256 and rgb[2] < 256:
                                背景颜色 = 转化为元组(背景颜色)
                                if 字体 != "宋体中文":
                                    字体 = pygame.font.SysFont(字体, 大小)
                                else:
                                    字体 = pygame.font.Font("宋体.ttc", 大小)
                                if g.ccbox(msg="是否开启抗锯齿（打开抗锯齿可以使导出的图片更加平滑）", title="字体图片工具", choices=["打开", "关闭"]):
                                    图片 = 字体.render(文字, True, 文字颜色, 背景颜色)
                                else:
                                    图片 = 字体.render(文字, False, 文字颜色, 背景颜色)
                                pygame.image.save(图片, 文字 + ".png")
                                奖励积分 = r.randint(1, 3)
                                g.msgbox(msg="文字“" + 文字 + "”导出成功，请到程序所在文件夹寻找图片！\n奖励你" + str(奖励积分) + "个积分。",
                                         title="字体图片工具",
                                         ok_button="返回首页")
                                return 奖励积分
                            else:
                                背景颜色输入错误()
                        else:
                            背景颜色输入错误()
                            奖励积分 = 0
                            return 奖励积分
                    else:
                        背景颜色输入错误()
                        奖励积分 = 0
                        return 奖励积分
                else:
                    背景颜色输入错误()
                    奖励积分 = 0
                    return 奖励积分
            else:
                文字颜色输入错误()
                奖励积分 = 0
                return 奖励积分
        else:
            g.msgbox(msg="文字大小输入错误！", title="字体图片工具", ok_button="返回首页")
            奖励积分 = 0
            return 奖励积分
    else:
        g.msgbox(msg="你必须选择一个字体！", title="字体图片工具", ok_button="返回首页")
        奖励积分 = 0
        return 奖励积分